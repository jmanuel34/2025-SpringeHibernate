package es.cursosprhib.medidosdepago.persistencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P01mdpPersistenciaSdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(P01mdpPersistenciaSdataApplication.class, args);
	}

}
