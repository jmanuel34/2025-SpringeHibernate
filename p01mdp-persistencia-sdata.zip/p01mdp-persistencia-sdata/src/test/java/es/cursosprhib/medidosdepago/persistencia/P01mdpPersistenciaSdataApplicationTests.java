package es.cursosprhib.medidosdepago.persistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P01mdpPersistenciaSdataApplicationTests {

	@Test
	void contextLoads() {
	}

}
